fn main() {
    println!("Hello, monads!");
}
